// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;





import "./App.css";
import React, { useState, useEffect } from "react";
import List from "./components/List";
import Alert from "./components/Alert";
// import Login from './components/Login';
import 'bootstrap/dist/css/bootstrap.css';
// import Registration from './components/Registration';
// import Landing from './components/Landing';





const App = () => {
  const[name,setName] = useState(" ");
  const[list,setList] = useState([]);
  const[isEditing,setIdEditing] = useState(false);
  const[editID,setEditID] = useState(null);
  const [alert, setAlert] = useState({show: false, msg:"", type: " "});

  const handleSubmit = (e) =>{
    e.preventDefault();
    if(!name){
      showAlert(true,'danger','Please Enter Value');

    }else if(name && isEditing){
      setList(
        list.map((item) =>{
          if(item.id === editID ){
            return{...item,title:name}
          }
          return item
        })
      );
      setName("");
      setEditID(null);
      setIdEditing(false);
      showAlert(true,"success","Value Changes");
    }else{
      showAlert(true , "success" ,"item Added to the List");
      const newItem = {id: new Date().getTime().toString(), title:name}
      setList([...list,newItem]);
      setName(" ");
    }
  };

  const showAlert = (show = false,type = " ",msg = " " ) => {
    setAlert(true,"danger","Item Removed");
    setList({show,type,msg});

  };
  const removeItem = (id) =>{
    showAlert(true)
  };
  const editItem = () =>{};
  const clearList = () =>{};
  
  

  return (
      <section className="section-center">
        <form onSumbit = {handleSubmit}>
            {alert.show && <Alert {...alert} removeAlert = {showAlert} list = {list} />}
            <h3 style={{marginBottom: "1.5rem", textAlign: "center"}}>
              Todo List
            </h3>
            <div className="mb-3 form">
              <input
              type="text"
              className="form-control"
              placeholder="e.g Design"
              onChange={(e) => setName(e.target.value)}
              value = {name}
              />
              <button type="submit" className =" btn btn-success">
                  {isEditing ? "Edit" : "Submit"}
              </button>
              

            </div>
        </form>
        {list.length > 0 && (
          <div style={{marginTop: "2rem"}}>
            <List items = {list} removeItem = {removeItem} editItem = {editItem}/> 
            <div className="text-center">
              <button className="btn btn-warning" onClick={clearList}> Clear Items</button>
            </div>
          </div>

        )}
      </section>
  );
}

export default App;

