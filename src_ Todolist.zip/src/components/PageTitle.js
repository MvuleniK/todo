import React from 'react'

function PageTitle(children) {
  return (
    <div className=''>
        <h1>Hello from title</h1>
    </div>
  )
}

export default PageTitle